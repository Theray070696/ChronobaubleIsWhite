Hey, you should use my other mod for this. It's configurable and doesn't just work on the Chronobauble. [Check it out here!](https://thunderstore.io/package/Theray070696/ItemTierSelection/)

Leaving this up for reasons.

Should be self explanatory what this mod does, but in case it's not, this mod turns the Chronobauble from a tier 2 (green) item into a tier 1 (white) item.